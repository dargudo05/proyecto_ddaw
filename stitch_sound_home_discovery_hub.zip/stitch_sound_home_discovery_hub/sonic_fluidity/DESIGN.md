---
name: Sonic Fluidity
colors:
  surface: '#131315'
  surface-dim: '#131315'
  surface-bright: '#39393b'
  surface-container-lowest: '#0e0e10'
  surface-container-low: '#1c1b1d'
  surface-container: '#201f21'
  surface-container-high: '#2a2a2c'
  surface-container-highest: '#353437'
  on-surface: '#e5e1e4'
  on-surface-variant: '#d4c0d7'
  inverse-surface: '#e5e1e4'
  inverse-on-surface: '#313032'
  outline: '#9d8ba0'
  outline-variant: '#504254'
  surface-tint: '#ebb2ff'
  primary: '#ebb2ff'
  on-primary: '#520072'
  primary-container: '#bc13fe'
  on-primary-container: '#ffffff'
  inverse-primary: '#9800d0'
  secondary: '#a6e6ff'
  on-secondary: '#003543'
  secondary-container: '#14d1ff'
  on-secondary-container: '#00566b'
  tertiary: '#ffb59c'
  on-tertiary: '#5c1900'
  tertiary-container: '#d54500'
  on-tertiary-container: '#110200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#f8d8ff'
  primary-fixed-dim: '#ebb2ff'
  on-primary-fixed: '#320047'
  on-primary-fixed-variant: '#74009f'
  secondary-fixed: '#b7eaff'
  secondary-fixed-dim: '#4cd6ff'
  on-secondary-fixed: '#001f28'
  on-secondary-fixed-variant: '#004e60'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59c'
  on-tertiary-fixed: '#390c00'
  on-tertiary-fixed-variant: '#832700'
  background: '#131315'
  on-background: '#e5e1e4'
  surface-variant: '#353437'
typography:
  h1:
    fontFamily: Space Grotesk
    fontSize: 64px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  h2:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h3:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Spline Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0em
  body-md:
    fontFamily: Spline Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0em
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 32px
  gutter: 24px
  section-gap: 64px
---

## Brand & Style

The brand personality is electric, fluid, and deeply immersive. Designed for a digitally native audience aged 15-30, the design system centers on the "musical family tree"—the organic, interconnected nature of genres and artists. It avoids the clinical feel of traditional libraries in favor of a "living" interface that responds to the energy of the music.

The design style is a sophisticated blend of **Glassmorphism** and **High-Contrast Minimalism**. It uses deep, dark voids to provide infinite depth, while translucent layers and vibrant blurs represent the "aura" of different musical energies. The emotional response should be one of discovery and "flow," where the UI feels like a natural extension of the audio experience.

## Colors

The palette is built on a "True Dark" foundation to ensure maximum contrast and immersion. 

- **Primary (Neon Purple):** Represents electronic, high-energy, and synth-heavy tones. Used for primary actions and "active" playback states.
- **Secondary (Electric Blue):** Represents chill, ambient, and technical precision. Used for secondary navigation and data visualization.
- **Tertiary (Sunset Orange):** Represents acoustic, soul, and vocal warmth. Used for discovery highlights and trending elements.
- **Backgrounds:** Use a base of `#0A0A0C`. Surface layers use varying degrees of transparency to allow "Energy Blurs" (large, soft radial gradients of the accent colors) to peak through from the background.

## Typography

This design system utilizes a high-hierarchy typographic approach to guide users through dense musical data. **Space Grotesk** is used for all headlines and functional labels to provide a technical, cutting-edge feel. For long-form content and metadata, **Spline Sans** offers a friendly, legible balance. 

Headlines should be tight and aggressive. Use "Label-Caps" for metadata like genre tags or timestamps to maintain a professional, organized look amidst the vibrant color palette.

## Layout & Spacing

The layout follows a **Fluid Grid** model with generous white space (or "dark space") to prevent the vibrant elements from feeling cluttered. A 12-column grid is standard for desktop, collapsing to a single column for mobile.

Spacing is based on a 4px baseline, but utilizes large-scale "breathing room" between sections (64px+) to emphasize the immersive, editorial nature of the platform. Elements should feel like they are floating in space rather than being boxed into a rigid container.

## Elevation & Depth

Depth is conveyed through **Glassmorphism** rather than traditional shadows. 

1.  **Base Layer:** Solid `#0A0A0C` background with subtle, slow-moving radial blurs of primary/secondary colors.
2.  **Surface Layer:** 40% opacity glass with a 20px backdrop blur and a 1px "inner glow" border (white at 10% opacity) to define edges.
3.  **Floating Layer:** Elements like cards or player controls use 60% opacity with 40px backdrop blurs to appear closer to the user.

Shadows, when used, are never black; they are ultra-diffused "glows" that match the hex code of the element's accent color (e.g., a purple button casts a soft purple glow).

## Shapes

The shape language is "Organic-Geometric." Standard interface components (buttons, inputs) use a **Rounded** (0.5rem) setting to maintain a modern, professional feel. 

However, for the "Musical Family Tree" and decorative background elements, use **Organic Blobs**. These are non-symmetrical, fluid shapes created with varying border-radius values (e.g., `60% 40% 30% 70% / 60% 30% 70% 40%`). These shapes should gently pulse or rotate to simulate a living organism.

## Components

- **Buttons:** Primary buttons are solid gradients (Neon Purple to Electric Blue) with high-contrast white text. Secondary buttons are "ghost" style with a glass background and a 1px border.
- **Glass Cards:** Used for album art and artist profiles. They feature a heavy backdrop blur and "frosted" borders. On hover, the backdrop blur intensity increases, and the accent color glow strengthens.
- **Energy Chips:** Small, pill-shaped tags used for genres. The background color of the chip reflects the "energy" (e.g., Orange for "Acoustic").
- **Inputs:** Ultra-minimalist bottom-border only, or fully translucent glass fields. The focus state triggers a neon glow of the Primary color.
- **The Tree Connector:** A custom component consisting of thin, glowing SVG lines that connect "Artist Cards," representing musical influences. These lines should have a slight "flow" animation.
- **Immersive Player:** A persistent bottom-bar component utilizing 80% background blur, allowing the content scrolling beneath it to be visible but diffused.